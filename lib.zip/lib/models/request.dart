import 'package:hive/hive.dart';

part 'request.g.dart';

@HiveType(typeId: 0)
class Request extends HiveObject {
  @HiveField(0)
  String title;

  @HiveField(1)
  String description;

  @HiveField(2)
  String firstName;

  @HiveField(3)
  String lastName;

  @HiveField(4)
  String type;

  @HiveField(5)
  String date;

  @HiveField(6)
  String status;

  @HiveField(7)
  String username; // added username field

  Request({
    required this.title,
    required this.description,
    this.firstName = '',
    this.lastName = '',
    this.type = 'General Inquiry',
    String? date,
    this.status = 'Pending',
    required this.username,
  }) : date = date ?? DateTime.now().toIso8601String();
}
