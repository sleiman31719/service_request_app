import 'request.dart';

class RequestStore {
  final List<Request> _requests = [];

  List<Request> get requests => List.unmodifiable(_requests);

  int get total => _requests.length;

  int get accepted =>
      _requests.where((r) => r.status.toLowerCase() == 'accepted').length;

  int get rejected =>
      _requests.where((r) => r.status.toLowerCase() == 'rejected').length;

  int get pending =>
      _requests.where((r) => r.status.toLowerCase() == 'pending').length;

  // Return only requests for a specific username
  List<Request> requestsForUser(String username) {
    return _requests.where((r) => r.username == username).toList();
  }

  void addRequest(Request request) {
    _requests.insert(0, request);
  }

  void updateRequestStatus(Request request, String newStatus) {
    final index = _requests.indexOf(request);
    if (index != -1) {
      _requests[index].status = newStatus;
    }
  }

  void deleteRequest(Request request) {
    _requests.remove(request);
  }
}
