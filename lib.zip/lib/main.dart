import 'package:flutter/material.dart';
import 'models/request_store.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SharedPreferences prefs = await SharedPreferences.getInstance();
  bool loggedIn = prefs.getBool('loggedIn') ?? false;
  String username = prefs.getString('username') ?? '';

  runApp(ServiceRequestApp(loggedIn: loggedIn, username: username));
}

class ServiceRequestApp extends StatefulWidget {
  final bool loggedIn;
  final String username;

  const ServiceRequestApp({
    Key? key,
    required this.loggedIn,
    required this.username,
  }) : super(key: key);

  @override
  State<ServiceRequestApp> createState() => _ServiceRequestAppState();
}

class _ServiceRequestAppState extends State<ServiceRequestApp> {
  final RequestStore requestStore = RequestStore();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Service Request App',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: widget.loggedIn ? '/home' : '/login',
      routes: {
        '/login': (context) => LoginScreen(
              onLogin: (username) {
                setState(() {});
                Navigator.pushReplacementNamed(context, '/home',
                    arguments: username);
              },
            ),
        '/signup': (context) => SignupScreen(),
        '/home': (context) {
          final username =
              ModalRoute.of(context)!.settings.arguments as String? ??
                  widget.username;
          return HomeScreen(
            requestStore: requestStore,
            username: username,
          );
        },
      },
    );
  }
}
