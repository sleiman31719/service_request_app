class RequestStorage {
  static final List<Map<String, String>> _requests = [];

  static void addRequest({required String title, required String description}) {
    _requests.add({'title': title, 'description': description});
  }

  static List<Map<String, String>> getRequests() {
    return _requests;
  }
}
