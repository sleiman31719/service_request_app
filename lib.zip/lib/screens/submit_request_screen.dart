import 'package:flutter/material.dart';
import '../models/request.dart';
import '../models/request_store.dart';
import '../widgets/background_widget.dart';

class SubmitRequestScreen extends StatefulWidget {
  final RequestStore requestStore;
  final String username;

  const SubmitRequestScreen({
    Key? key,
    required this.requestStore,
    required this.username,
  }) : super(key: key);

  @override
  State<SubmitRequestScreen> createState() => _SubmitRequestScreenState();
}

class _SubmitRequestScreenState extends State<SubmitRequestScreen> {
  final _formKey = GlobalKey<FormState>();

  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _titleController = TextEditingController();
  final _descController = TextEditingController();

  String? _selectedRequestType;

  final List<String> _requestTypes = [
    'Technical Support',
    'Maintenance',
    'Billing',
    'General Inquiry',
  ];

  @override
  void initState() {
    super.initState();
    final parts = widget.username.split(' ');
    _firstNameController.text = parts.isNotEmpty ? parts[0] : '';
    _lastNameController.text = parts.length > 1 ? parts[1] : '';
  }

  void _submit() {
    if (_formKey.currentState?.validate() != true) return;

    final newRequest = Request(
      title: _titleController.text,
      description: _descController.text,
      firstName: _firstNameController.text,
      lastName: _lastNameController.text,
      type: _selectedRequestType ?? 'General Inquiry',
      date: DateTime.now().toIso8601String(),
      status: 'Pending',
      username: widget.username, // assign username here
    );

    widget.requestStore.addRequest(newRequest);

    Navigator.pop(context, true);
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _titleController.dispose();
    _descController.dispose();
    super.dispose();
  }

  InputDecoration _inputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BackgroundWidget(
        imagePath: 'assets/images/SubmitRequest.jpg',
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Form(
              key: _formKey,
              child: ListView(
                children: [
                  const Text(
                    'Submit a Request',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    controller: _firstNameController,
                    decoration: _inputDecoration('First Name'),
                    validator: (value) =>
                        value == null || value.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _lastNameController,
                    decoration: _inputDecoration('Last Name'),
                    validator: (value) =>
                        value == null || value.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _selectedRequestType,
                    decoration: _inputDecoration('Request Type'),
                    items: _requestTypes
                        .map((type) => DropdownMenuItem(
                              value: type,
                              child: Text(type),
                            ))
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedRequestType = value;
                      });
                    },
                    validator: (value) =>
                        value == null || value.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _titleController,
                    decoration: _inputDecoration('Title'),
                    validator: (value) =>
                        value == null || value.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _descController,
                    maxLines: 5,
                    decoration: _inputDecoration('Description'),
                    validator: (value) =>
                        value == null || value.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _submit,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                        backgroundColor: Colors.blueAccent,
                      ),
                      child: const Text(
                        'Submit Request',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
