import 'package:flutter/material.dart';
import '../models/request_store.dart';
import '../widgets/background_widget.dart';
import 'request_detail_screen.dart';

class RequestsListScreen extends StatelessWidget {
  final RequestStore requestStore;
  final String username;

  const RequestsListScreen({
    Key? key,
    required this.requestStore,
    required this.username,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final requests = requestStore.requestsForUser(username);

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Requests'),
        backgroundColor: Colors.black87,
      ),
      body: BackgroundWidget(
        imagePath: 'assets/images/RequestList.jpg',
        child: requests.isEmpty
            ? const Center(
                child: Text(
                  'No requests found',
                  style: TextStyle(color: Colors.white70, fontSize: 18),
                ),
              )
            : ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: requests.length,
                separatorBuilder: (_, __) =>
                    const Divider(color: Colors.white24, height: 1),
                itemBuilder: (context, index) {
                  final req = requests[index];
                  return ListTile(
                    tileColor: Colors.white.withOpacity(0.9),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    title: Text(
                      req.title,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    subtitle: Text(
                      '${req.firstName} ${req.lastName} • ${req.type}',
                      style: const TextStyle(fontSize: 14),
                    ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _statusIcon(req.status),
                        const SizedBox(height: 4),
                        Text(
                          _formatDate(req.date),
                          style: const TextStyle(
                              fontSize: 11, color: Colors.black54),
                        ),
                      ],
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RequestDetailScreen(
                            request: req,
                            requestStore: requestStore,
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
      ),
    );
  }

  Widget _statusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return const Icon(Icons.hourglass_empty, color: Colors.orangeAccent);
      case 'accepted':
        return const Icon(Icons.check_circle, color: Colors.green);
      case 'rejected':
        return const Icon(Icons.cancel, color: Colors.redAccent);
      default:
        return const Icon(Icons.help_outline, color: Colors.white);
    }
  }

  String _formatDate(String isoDate) {
    try {
      final date = DateTime.parse(isoDate);
      return '${date.day}/${date.month}/${date.year}';
    } catch (_) {
      return '';
    }
  }
}
