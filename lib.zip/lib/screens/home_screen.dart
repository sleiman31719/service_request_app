import 'dart:async';
import 'package:flutter/material.dart';
import '../models/request_store.dart';
import '../widgets/background_widget.dart';
import 'submit_request_screen.dart';
import 'requests_list_screen.dart';
import 'request_detail_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeScreen extends StatefulWidget {
  final RequestStore requestStore;
  final String username;

  const HomeScreen({
    Key? key,
    required this.requestStore,
    required this.username,
  }) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();

    _timer = Timer.periodic(const Duration(seconds: 2), (timer) {
      setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _logout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('loggedIn', false);
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    // Filter requests to only those by current user
    final userRequests = widget.requestStore.requestsForUser(widget.username);
    final recentRequests =
        userRequests.length > 5 ? userRequests.sublist(0, 5) : userRequests;

    return Scaffold(
      body: BackgroundWidget(
        imagePath: 'assets/images/background.jpg',
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: ConstrainedBox(
                    constraints:
                        BoxConstraints(minHeight: constraints.maxHeight),
                    child: IntrinsicHeight(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Logo and Welcome Row
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Image.asset(
                                    'assets/images/logo.jpg',
                                    height: 48,
                                  ),
                                  const SizedBox(width: 12),
                                  Text(
                                    'Welcome, ${widget.username}!',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold,
                                      shadows: [
                                        Shadow(
                                          blurRadius: 3,
                                          color: Colors.black45,
                                          offset: Offset(1, 1),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              TextButton(
                                onPressed: () => _logout(context),
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor:
                                      Colors.redAccent.withOpacity(0.8),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 8),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                                child: const Text('Logout'),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),

                          // Stats Cards - horizontal list
                          SizedBox(
                            height: 130,
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              children: [
                                _buildStatCard(
                                  title: 'Total Requests',
                                  count: userRequests.length,
                                  color: Colors.blueAccent,
                                ),
                                _buildStatCard(
                                  title: 'Accepted',
                                  count: userRequests
                                      .where((r) =>
                                          r.status.toLowerCase() == 'accepted')
                                      .length,
                                  color: Colors.green,
                                ),
                                _buildStatCard(
                                  title: 'Rejected',
                                  count: userRequests
                                      .where((r) =>
                                          r.status.toLowerCase() == 'rejected')
                                      .length,
                                  color: Colors.redAccent,
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 20),

                          const Text(
                            'Recent Requests',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w700,
                              shadows: [
                                Shadow(
                                  blurRadius: 2,
                                  color: Colors.black54,
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Recent Requests List inside Expanded
                          recentRequests.isEmpty
                              ? Container(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 40),
                                  alignment: Alignment.center,
                                  child: Text(
                                    'No recent requests',
                                    style: TextStyle(
                                      color: Colors.white70.withOpacity(0.85),
                                      fontSize: 18,
                                      fontStyle: FontStyle.italic,
                                    ),
                                  ),
                                )
                              : ListView.separated(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount: recentRequests.length,
                                  separatorBuilder: (_, __) => Divider(
                                      color: Colors.white24.withOpacity(0.7)),
                                  itemBuilder: (context, index) {
                                    final req = recentRequests[index];
                                    return Card(
                                      color: Colors.white.withOpacity(0.9),
                                      elevation: 5,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(14)),
                                      margin: const EdgeInsets.symmetric(
                                          vertical: 8),
                                      child: ListTile(
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                                horizontal: 16, vertical: 10),
                                        title: Text(
                                          req.title,
                                          style: const TextStyle(
                                              color: Colors.black87,
                                              fontWeight: FontWeight.w600),
                                        ),
                                        subtitle: Text(
                                          'Status: ${req.status}  •  ${_formatDate(req.date)}',
                                          style: const TextStyle(
                                              color: Colors.black54,
                                              fontSize: 14),
                                        ),
                                        trailing: _statusIcon(req.status),
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  RequestDetailScreen(
                                                request: req,
                                                requestStore:
                                                    widget.requestStore,
                                              ),
                                            ),
                                          ).then((refresh) {
                                            if (refresh == true)
                                              setState(() {});
                                          });
                                        },
                                      ),
                                    );
                                  },
                                ),

                          const SizedBox(height: 24),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              ElevatedButton.icon(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => SubmitRequestScreen(
                                        requestStore: widget.requestStore,
                                        username: widget.username,
                                      ),
                                    ),
                                  ).then((refresh) {
                                    if (refresh == true) setState(() {});
                                  });
                                },
                                icon: const Icon(Icons.add_circle_outline),
                                label: const Text('Submit Request'),
                                style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20, vertical: 14),
                                  textStyle: const TextStyle(fontSize: 16),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12)),
                                  backgroundColor: Colors.blueAccent,
                                ),
                              ),
                              ElevatedButton.icon(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => RequestsListScreen(
                                        requestStore: widget.requestStore,
                                        username: widget.username,
                                      ),
                                    ),
                                  ).then((refresh) {
                                    if (refresh == true) setState(() {});
                                  });
                                },
                                icon: const Icon(Icons.list),
                                label: const Text('View Requests'),
                                style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20, vertical: 14),
                                  textStyle: const TextStyle(fontSize: 16),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12)),
                                  backgroundColor: Colors.green,
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 12),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required String title,
    required int count,
    required Color color,
  }) {
    return Container(
      width: 140,
      margin: const EdgeInsets.only(right: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.9),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.7),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$count',
            style: const TextStyle(
                fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.white70),
          ),
        ],
      ),
    );
  }

  Widget _statusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return const Icon(Icons.hourglass_empty, color: Colors.orangeAccent);
      case 'accepted':
        return const Icon(Icons.check_circle, color: Colors.green);
      case 'rejected':
        return const Icon(Icons.cancel, color: Colors.redAccent);
      default:
        return const Icon(Icons.help_outline, color: Colors.grey);
    }
  }

  String _formatDate(String isoDate) {
    try {
      final date = DateTime.parse(isoDate);
      return '${date.day}/${date.month}/${date.year}';
    } catch (_) {
      return '';
    }
  }
}
