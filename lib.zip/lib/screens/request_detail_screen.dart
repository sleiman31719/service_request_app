import 'package:flutter/material.dart';
import '../models/request.dart';
import '../models/request_store.dart';
import '../widgets/background_widget.dart';

class RequestDetailScreen extends StatefulWidget {
  final Request request;
  final RequestStore requestStore;

  const RequestDetailScreen({
    Key? key,
    required this.request,
    required this.requestStore,
  }) : super(key: key);

  @override
  State<RequestDetailScreen> createState() => _RequestDetailScreenState();
}

class _RequestDetailScreenState extends State<RequestDetailScreen> {
  late Request _request;

  @override
  void initState() {
    super.initState();
    _request = widget.request;
  }

  void _updateStatus(String newStatus) {
    setState(() {
      _request.status = newStatus;
      widget.requestStore.updateRequestStatus(_request, newStatus);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Request Detail'),
        backgroundColor: Colors.black87,
      ),
      body: BackgroundWidget(
        imagePath: 'assets/images/background.jpg',
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: ListView(
            children: [
              Text(
                _request.title,
                style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
              const SizedBox(height: 12),
              Text(
                'Submitted by: ${_request.firstName} ${_request.lastName}',
                style: const TextStyle(fontSize: 18, color: Colors.white70),
              ),
              const SizedBox(height: 8),
              Text(
                'Type: ${_request.type}',
                style: const TextStyle(fontSize: 16, color: Colors.white70),
              ),
              const SizedBox(height: 12),
              Text(
                _request.description,
                style: const TextStyle(fontSize: 16, color: Colors.white),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Text(
                    'Status: ',
                    style: const TextStyle(fontSize: 18, color: Colors.white70),
                  ),
                  _statusIcon(_request.status),
                  const SizedBox(width: 8),
                  Text(
                    _request.status,
                    style: const TextStyle(fontSize: 18, color: Colors.white70),
                  )
                ],
              ),
              const SizedBox(height: 20),
              if (_request.status.toLowerCase() == 'pending')
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () => _updateStatus('Accepted'),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12)),
                      child: const Text('Accept'),
                    ),
                    ElevatedButton(
                      onPressed: () => _updateStatus('Rejected'),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.redAccent,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12)),
                      child: const Text('Reject'),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return const Icon(Icons.hourglass_empty, color: Colors.orangeAccent);
      case 'accepted':
        return const Icon(Icons.check_circle, color: Colors.green);
      case 'rejected':
        return const Icon(Icons.cancel, color: Colors.redAccent);
      default:
        return const Icon(Icons.help_outline, color: Colors.white);
    }
  }
}
